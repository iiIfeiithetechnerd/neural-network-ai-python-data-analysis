pip install --upgrade pip
pip install tensorflow pandas numpy matplotlib

echo "Yay! The setup is complete!"
python3 main.py

python3 main.py

# Run these commands in the command promt, not this bash file itself.
    #chmod +x tensor_install.sh
    #./tensor_install.sh